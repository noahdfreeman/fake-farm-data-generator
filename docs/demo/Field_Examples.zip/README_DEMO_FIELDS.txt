DEMO FIELD BOUNDARIES

These three GeoPackage files are public example inputs for Fake Farm Data
Generator. They contain no grower, farm, or owner identity information.

Use one or more of these files as field-boundary layers in the plugin. The
plugin will create clearly labeled fake soil-test, planting, as-applied, and
yield data inside the selected boundaries.

The field geometries are demonstration inputs and are not legal surveys.
